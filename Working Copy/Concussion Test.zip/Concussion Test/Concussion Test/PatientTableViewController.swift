//
//  PatientTableViewController.swift
//  Concussion Test
//
//  Created by workinman002 on 5/5/16.
//  Copyright © 2016 Slouch Design. All rights reserved.
//

import UIKit

class PatientTableViewController: UITableViewController {

    // MARK: [Properties]
    private let NUM_SPORTS : Int = 10
    
    private var _baseball   = [Patient]()
    private var _basketball = [Patient]()
    private var _football   = [Patient]()
    private var _hockey     = [Patient]()
    private var _lacrosse   = [Patient]()
    private var _soccer     = [Patient]()
    private var _swimming   = [Patient]()
    private var _tennis     = [Patient]()
    private var _track      = [Patient]()
    private var _wrestling  = [Patient]()
    
    var patients = [Patient]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Use the edit button item provided by the table view controller
        navigationItem.leftBarButtonItem = editButtonItem()
        
        //loadSamplePatients()
        
        // [Load any saved data]
        if let savedPatients = loadPatients(){
            patients += savedPatients
            
            for patient in patients {
                addPatient(patient)
            }
        }else{
            // load sample data
            loadSamplePatients()
        }
    }
    
    func loadSamplePatients(){
        let photo1 = UIImage(named:"patient1")!
        let patient1 = Patient(firstName: "Justin", lastName: "Dambra", photo: photo1, rating: 4, sport:0)!
        
        let photo2 = UIImage(named:"patient2")!
        let patient2 = Patient(firstName: "Brian", lastName: "Panda", photo: photo2, rating: 2, sport:1)!
        
        let photo3 = UIImage(named:"patient3")!
        let patient3 = Patient(firstName: "Drake", lastName: "Low", photo: photo3, rating: 5, sport:2)!
        
        _baseball.append(patient1)
        _basketball.append(patient2)
        _football.append(patient3)
    }
    
    func numberOfPopulatedArrays()->Int{
        var tNumArrays = 0;
        
        if(_baseball.count > 0){
            tNumArrays+=1;
        }
        
        return tNumArrays;
    }
    
    func addArrayCount( pArray:[Patient]?) -> Int{
        if(pArray!.count > 0){
            return 1;
        }
        
        return 0;
    }

    override func didReceiveMemoryWarning() {
        // Dispose of any resources that can be recreated.
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        // Section Header Title
        return AppManager.getSportString(section)
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections
        return NUM_SPORTS
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section
        return getCorrectSport(section)!.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "PatientTableViewCell";
        
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! PatientTableViewCell
        
        // [Set Patient]
        let patient = getCorrectSport(indexPath.section)![indexPath.row];
        
        cell.fullName.text = patient.lastName + ", " + patient.firstName;
        cell.photoImageView.image = patient.photo;
        cell.ratingControl.rating = patient.rating;

        return cell
    }

    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            removePatient(indexPath.section, index:indexPath.row)
            savePatients()
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if(segue.identifier == "ShowDetail"){
            let patientDetailViewController = segue.destinationViewController as! PatientViewController;
            
            if let selectedPatientCell = sender as? PatientTableViewCell {
                let indexPath = tableView.indexPathForCell(selectedPatientCell)!
                
                // [Selected Patient Data]
                let selectedPatient = getCorrectSport(indexPath.section)![indexPath.row]
                patientDetailViewController.patient = selectedPatient;
            }
            
            // print("Editing existing patient");
        }else if(segue.identifier == "AddItem"){
            // print("Adding new patient.");
        }
    }
    
    // [Moving To TableViewController]
    @IBAction func unwindToPatientList(sender:UIStoryboardSegue){
        if let sourceViewController = sender.sourceViewController as? PatientViewController, patient = sourceViewController.patient{
            
            if let selectedIndexPath = tableView.indexPathForSelectedRow{
                // [Update Existing Patient If Sport Did Not Change]
                
                // patients[selectedIndexPath.row] = patient;
                
                // getCorrectSport(selectedIndexPath.section)[selectedIndexPath.row] = patient
                tableView.reloadRowsAtIndexPaths([selectedIndexPath], withRowAnimation: .None);
                
            }else{
                // [Adds New Patient at Correct Row And Section]
                addPatient(patient);
                
                // [Finds Correct Index To Place Patient In Table]
                var count:Int = 0;
                let tSportArray:[Patient] = getCorrectSport(patient.sport.rawValue)!;
                for athlete in tSportArray{
                    if(patient == athlete){
                        break;
                    }
                    count+=1;
                }
                
                let newIndexPath = NSIndexPath(forRow: count, inSection: patient.sport.rawValue);
                tableView.insertRowsAtIndexPaths([newIndexPath], withRowAnimation: .Bottom);
            }

            // [Save Patients]
            savePatients();
        }
    }
    
    // MARK: Helper Functions
    
    // [Return Correct Array] DO NOT CALL WHEN TRYING TO CHANGE/EDIT DATA
    func getCorrectSport(section:Int) ->[Patient]? {
        switch(section){
        case Patient.Sport.Baseball.rawValue:
            return _baseball
        case Patient.Sport.Basketball.rawValue:
            return _basketball
        case Patient.Sport.Football.rawValue:
            return _football
        case Patient.Sport.Hockey.rawValue:
            return _hockey
        case Patient.Sport.Lacrosse.rawValue:
            return _lacrosse
        case Patient.Sport.Soccer.rawValue:
            return _soccer
        case Patient.Sport.Swimming.rawValue:
            return _swimming
        case Patient.Sport.Tennis.rawValue:
            return _tennis
        case Patient.Sport.Track.rawValue:
            return _track
        case Patient.Sport.Wrestling.rawValue:
            return _wrestling
        default:
            // [THIS SHOULD NEVER HAPPEN]
            print("[PatientTableViewController] trying to access an inexistant sport")
            return nil;
        }
    }
    
    // [Add Patient To Correct Array]
    func addPatient(patient:Patient){
        switch(patient.sport.rawValue){
        case Patient.Sport.Baseball.rawValue:
            _baseball.append(patient)
            _baseball = _baseball.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Basketball.rawValue:
            _basketball.append(patient)
            _basketball = _basketball.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Football.rawValue:
            _football.append(patient)
            _football = _football.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Hockey.rawValue:
            _hockey.append(patient)
            _hockey = _hockey.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Lacrosse.rawValue:
            _lacrosse.append(patient)
            _lacrosse = _lacrosse.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Soccer.rawValue:
            _soccer.append(patient)
            _soccer = _soccer.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Swimming.rawValue:
            _swimming.append(patient)
            _swimming = _swimming.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Tennis.rawValue:
            _tennis.append(patient)
            _tennis = _tennis.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Track.rawValue:
            _track.append(patient)
            _track = _track.sort({ $0.lastName < $1.lastName })
        case Patient.Sport.Wrestling.rawValue:
            _wrestling.append(patient)
            _wrestling = _wrestling.sort({ $0.lastName < $1.lastName })
        default:
            print("[PatientTableViewController] (addPatient) ERROR. Should Not Get Here")
        }
    }
    
    // [Remove Patient From Array]
    func removePatient(section:Int, index:Int){
        switch(section){
        case Patient.Sport.Baseball.rawValue:
            _baseball.removeAtIndex(index)
        case Patient.Sport.Basketball.rawValue:
            _basketball.removeAtIndex(index)
        case Patient.Sport.Football.rawValue:
            _football.removeAtIndex(index)
        case Patient.Sport.Hockey.rawValue:
            _hockey.removeAtIndex(index)
        case Patient.Sport.Lacrosse.rawValue:
            _lacrosse.removeAtIndex(index)
        case Patient.Sport.Soccer.rawValue:
            _soccer.removeAtIndex(index)
        case Patient.Sport.Swimming.rawValue:
            _swimming.removeAtIndex(index)
        case Patient.Sport.Tennis.rawValue:
            _tennis.removeAtIndex(index)
        case Patient.Sport.Track.rawValue:
            _track.removeAtIndex(index)
        case Patient.Sport.Wrestling.rawValue:
            _wrestling.removeAtIndex(index)
        default:
            print("[PatientTableViewController] (removePatient) ERROR. Should Not Get Here")
        }
    }
    
    // [Saves Patient Into Final Array]
    func savePatient(pSport:[Patient]?) {
        for patient in pSport! {
            patients.append(patient)
        }
    }
    
    // MARK: [NSCoding]
    func savePatients(){
        patients.removeAll()
        
        // Saves All Patients Into One Array
        savePatient(_baseball);
        savePatient(_basketball);
        savePatient(_football);
        savePatient(_hockey);
        savePatient(_lacrosse);
        savePatient(_soccer);
        savePatient(_swimming);
        savePatient(_tennis);
        savePatient(_track);
        savePatient(_wrestling);
        
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(patients, toFile: Patient.ArchiveURL.path!);
        
        if !isSuccessfulSave{
            print("Failed to save patient");
        }
    }
    
    func loadPatients() ->[Patient]?{
        return NSKeyedUnarchiver.unarchiveObjectWithFile(Patient.ArchiveURL.path!) as? [Patient];
    }
}
