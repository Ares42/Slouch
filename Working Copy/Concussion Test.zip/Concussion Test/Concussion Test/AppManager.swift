//
//  AppManager.swift
//  Concussion Test
//
//  Created by workinman002 on 5/9/16.
//  Copyright © 2016 Slouch Design. All rights reserved.
//

import Foundation

class AppManager{
    
    // MARK: [Static Functions]
    static func getSportString( sportEnum:Int ) -> String?{
        switch sportEnum {
        case Patient.Sport.Baseball.rawValue:
            return "Baseball"
        case Patient.Sport.Basketball.rawValue:
            return "Basketball"
        case Patient.Sport.Football.rawValue:
            return "Football"
        case Patient.Sport.Hockey.rawValue:
            return "Hockey"
        case Patient.Sport.Lacrosse.rawValue:
            return "Lacrosse"
        case Patient.Sport.Soccer.rawValue:
            return "Soccer"
        case Patient.Sport.Swimming.rawValue:
            return "Swimming"
        case Patient.Sport.Tennis.rawValue:
            return "Tennis"
        case Patient.Sport.Track.rawValue:
            return "Track"
        case Patient.Sport.Wrestling.rawValue:
            return "Wrestling"
        default:
            return ""
        }
    }
}
