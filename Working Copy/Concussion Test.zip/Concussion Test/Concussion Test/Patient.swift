//
//  Patient.swift
//  Concussion Test
//
//  Created by workinman002 on 5/5/16.
//  Copyright © 2016 Slouch Design. All rights reserved.
//

import UIKit

class Patient:NSObject, NSCoding{
    
    // MARK: [Properties]
    var firstName:String;
    var lastName:String;
    var photo:UIImage?;
    var rating:Int;
    var sport:Sport;
    
    struct PropertyKey {
        static let firstNameKey = "firstName"
        static let lastNameKey = "lastName"
        static let photoKey = "photo"
        static let ratingKey = "rating"
        static let sportKey = "sport"
        static let rowKey = "row"
    }
    
    enum Sport:Int {
        case Baseball = 0
        case Basketball = 1
        case Football = 2
        case Hockey = 3
        case Lacrosse = 4
        case Soccer = 5
        case Swimming = 6
        case Tennis = 7
        case Track = 8
        case Wrestling = 9
    }
    
    // MARK: [Archiving Paths]
    static let DocumentsDirectory = NSFileManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.URLByAppendingPathComponent("patients");
    
    // MARK: [Initialization]
    init?(firstName:String, lastName:String, photo:UIImage?, rating:Int, sport:Int){
        self.firstName = firstName;
        self.lastName = lastName;
        self.photo = photo;
        self.rating = rating;
        self.sport = Sport(rawValue:sport)!;
        
        super.init();
        
        if(firstName.isEmpty || lastName.isEmpty || rating < 0){
            return nil;
        }
    }
    
    // MARK: [TableView Methods]

    
    // MARK: [NSCoding]
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(firstName, forKey: PropertyKey.firstNameKey);
        aCoder.encodeObject(lastName, forKey: PropertyKey.lastNameKey);
        aCoder.encodeObject(photo, forKey: PropertyKey.photoKey);
        aCoder.encodeInteger(rating, forKey: PropertyKey.ratingKey);
        aCoder.encodeInteger(sport.rawValue, forKey: PropertyKey.sportKey);
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        let firstName = aDecoder.decodeObjectForKey(PropertyKey.firstNameKey) as! String;
        let lastName = aDecoder.decodeObjectForKey(PropertyKey.lastNameKey) as! String;
        let photo = aDecoder.decodeObjectForKey(PropertyKey.photoKey) as? UIImage;
        let rating = aDecoder.decodeIntegerForKey(PropertyKey.ratingKey);
        let sport = aDecoder.decodeIntegerForKey(PropertyKey.sportKey);
        let row = aDecoder.decodeIntegerForKey(PropertyKey.rowKey);
        
        self.init(firstName:firstName, lastName: lastName, photo: photo, rating: rating, sport:sport);
    }
}
